# Global Electronics Retailer

Sales data for a fictitious global electronics retailer, including tables containing information about transactions, products, customers, stores and currency exchange rates.

## Recommended Analysis

- What types of products does the company sell, and where are customers located?
- Are there any seasonal patterns or trends for order volume or revenue?
- How long is the average delivery time in days? Has that changed over time?
- Is there a difference in average order value (AOV) for online vs. in-store sales?
